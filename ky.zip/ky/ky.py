import tkinter as tk
import serial
import time
import threading
import matplotlib
matplotlib.use("TkAgg")

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt

# =========================
# SERIAL CONFIG
# =========================
GRBL_PORT = 'COM11'      # ganti sesuai port Arduino kamu
ENCODER_PORT = 'COM12'
GCODE_FILE = 'KotakSaja-B_Cu.gbr_iso_combined_cnc_flatcam.txt'  # nama file G-code kamu
BAUD = 115200

grbl = serial.Serial(GRBL_PORT, BAUD)
encoder = serial.Serial(ENCODER_PORT, BAUD)
time.sleep(2)

# =========================
# DATA
# =========================
x_data = []
y_data = []

tick_x = 0
tick_y = 0

X_MAX = 100 #ukuran dalam mm
Y_MAX = 100 #ukuran dalam mm

# =========================
# GUI SETUP
# =========================
root = tk.Tk()
root.title("GUI Sistem Pengawasan dan Keamanan Mesin CNC 3 Axis untuk Milling PCB")
root.geometry("1000x600")
root.configure(bg="#d9d9d9")

main_frame = tk.Frame(root, bg="#d9d9d9")
main_frame.pack(fill="both", expand=True, padx=10, pady=10)

# Judul
title = tk.Label(
    main_frame,
    text="VISUAL JALUR PCB",
    font=("Arial", 14, "bold"),
    bg="#d9d9d9"
)
title.pack(pady=5)

# Frame abu-abu
frame_plot = tk.Frame(main_frame, bg="#bfbfbf", bd=2, relief="solid")
frame_plot.pack(fill="both", expand=True, padx=10, pady=10)

fig = plt.figure(figsize=(6,5))
ax = fig.add_subplot(111)
canvas = FigureCanvasTkAgg(fig, master=frame_plot)
canvas.get_tk_widget().pack(fill="both", expand=True)
# ==========================
# FUNGSI TUNGGU RESPON GRBL
# ==========================
def wait_grbl_ok():
    while True:
        response = grbl.readline().decode(errors="ignore").strip()
        if response != "":
            print("<<", response)

        #GRBL konfirmasi kalau diterima
        if response.lower() == "ok":
            return True

        #kalau error
        if "error" in response.lower():
            print("GRBL error")
            return False

def send_gcode():
    grbl.write(b"\r\n\r\n")
    time.sleep(2)
    grbl.flushInput()

    with open(GCODE_FILE, 'r') as file:
        lines = file.readlines()

    for line in lines:
        l = line.strip()
        if l == '' or l.startswith('('):
            continue

        print(">>", l)
        grbl.write((l + '\n').encode())

        success = wait_grbl_ok()
        if not success:
            print("STOP karena error")
            break

    print("✅ G-code selesai")

# =========================
# MATPLOTLIB
# =========================
fig = plt.figure(figsize=(6,5))
ax = fig.add_subplot(111)
canvas = FigureCanvasTkAgg(fig, master=frame_plot)
canvas.get_tk_widget().pack(fill="both", expand=True)

# =========================
# THREAD SERIAL
# =========================
def read_encoder():
    global tick_x, tick_y

    while True:
        try:
            line = encoder.readline().decode().strip()
            if not line:
                continue

            tx, ty = map(int, line.split(','))

            tick_x = tx
            tick_y = ty

        except:
            pass

# =========================
# UPDATE PLOT (FIXED)
# =========================
def update_plot():
    x_mm = tick_x * 1#0.05
    y_mm = tick_y * 1#0.2

    # filter biar ga kayak grafik air
    if len(x_data) == 0 or (abs(x_mm - x_data[-1]) > 0.02 or abs(y_mm - y_data[-1]) > 0.02):
        x_data.append(x_mm)
        y_data.append(y_mm)

    ax.clear()

    # jalur CNC
    ax.plot(x_data, y_data, linewidth=2)

    # titik tool
    if len(x_data) > 0:
        ax.scatter(x_data[-1], y_data[-1])

    # FIX TAMPILAN
    ax.set_xlim(0, X_MAX)
    ax.set_ylim(0, Y_MAX)
    ax.set_aspect('equal', adjustable='box')

    ax.set_title("Real Path Encoder")
    ax.set_xlabel("X (mm)")
    ax.set_ylabel("Y (mm)")
    ax.grid(True)

    canvas.draw()

    root.after(50, update_plot)

# =========================
# START THREAD
# =========================
threading.Thread(target=read_encoder, daemon=True).start()
threading.Thread(target=send_gcode, daemon=True).start()
# start plot
update_plot()

# =========================
# RUN
# =========================
root.mainloop()
