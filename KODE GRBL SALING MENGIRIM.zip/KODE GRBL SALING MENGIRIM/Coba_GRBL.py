import serial
import time

# === KONFIGURASI SERIAL ===
GRBL_PORT = 'COM11'      # ganti sesuai port Arduino kamu
ARUS_PORT = 'COM12'
BAUDRATE = 115200  # default GRBL baudrate
GCODE_FILE = 'KotakSaja-B_Cu.gbr_iso_combined_cnc_flatcam.txt'  # nama file G-code kamu

# === BUKA KONEKSI SERIAL ===
grbl = serial.Serial(GRBL_PORT, BAUDRATE)
arus = serial.Serial(ARUS_PORT, 115200)
time.sleep(2)  # tunggu GRBL reset

#BACA SENSOR ARUS
def read_current():
    if arus.in_waiting:
        data = arus.readline().decode(errors="ignore").strip()
        print("ARUS:", data, "mA")
        
# ==========================
# FUNGSI TUNGGU RESPON GRBL
# ==========================

def wait_grbl_ok():
    while True:
        read_current()
        response = grbl.readline().decode(errors="ignore").strip()
        if response != "":
            print("<<", response)

        #GRBL konfirmasi kalau diterima
        if response.lower() == "ok":
            return True

        #kalau error
        if "error" in response.lower():
            print("GRBL error")
            return False
        

# === CEK SIAP GRBL ===
grbl.write(b"\r\n\r\n")  # kirim enter dua kali biar GRBL respon
time.sleep(2)
grbl.flushInput()

# === BACA FILE G-CODE ===
with open(GCODE_FILE, 'r') as file:
    lines = file.readlines()

# === KIRIM BARIS DEMI BARIS ===
for line in lines:
    l = line.strip()
    if l == '' or l.startswith('('):  # lewati baris kosong/komentar
        continue
    print (">>", l)

    cmd = (l + '\n').encode()
    grbl.write(cmd)
    #grbl_out = ser.readline().decode().strip()

    #tunggu verifikasi grbl yang terkirim
    success = wait_grbl_ok()

    if not success:
        print("stop pengiriman ada error")

# === SELESAI ===
grbl.close()
arus.close()
print("✅ G-code selesai dikirim.")
