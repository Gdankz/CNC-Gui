import serial
import time

PORT = "COM11"
BAUDRATE = 115200
GCODE_FILE = "Kotak2.txt"

ser = serial.Serial(PORT, BAUDRATE, timeout=0.1)
time.sleep(2)

ser.write(b"\r\n\r\n")
time.sleep(2)
ser.flushInput()

with open(GCODE_FILE) as f:
    lines = [l.strip() for l in f if l.strip() and not l.startswith("(")]

buffer_size = 10      # jumlah line di buffer
line_index = 0
pending = 0

print("Start streaming...")

while True:

    # isi buffer
    while pending < buffer_size and line_index < len(lines):
        cmd = lines[line_index]
        ser.write((cmd + "\n").encode())
        print(">>", cmd)

        line_index += 1
        pending += 1

    # baca respon GRBL
    while ser.in_waiting:
        response = ser.readline().decode().strip()
        if response:
            print("<<", response)
            if response.lower() == "ok":
                pending -= 1

    #selesai
    if line_index >= len(lines) and pending == 0:
        break

    time.sleep(0.001)
ser.close()
print("DONE")
