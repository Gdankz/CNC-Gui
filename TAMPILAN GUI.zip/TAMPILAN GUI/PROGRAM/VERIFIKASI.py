import tkinter as tk
from tkinter import messagebox

# ======================
# WINDOW UTAMA
# ======================
root = tk.Tk()
root.title("Sistem Pengawasan CNC")
root.geometry("700x450")
root.configure(bg="#bfbfbf")   # background abu

# ======================
# HEADER
# ======================
header = tk.Label(
    root,
    text="PANEL VERIFIKASI PENGGUNA",
    font=("Arial", 16, "bold"),
    bg="#bfbfbf"
)
header.pack(pady=20)

# ======================
# FRAME PANEL
# ======================
panel = tk.Frame(root, bg="#bfbfbf")
panel.pack()

# Label Nama
label_nama = tk.Label(
    panel,
    text="Masukkan Nama Dulu Ya",
    font=("Arial", 14),
    bg="#bfbfbf"
)
label_nama.pack(pady=5)

# Entry Nama
entry_nama = tk.Entry(
    panel,
    font=("Arial", 12),
    justify="center",
    width=25,
    bg="#9e9e9e"
)
entry_nama.insert(0, "Isikan Nama")
entry_nama.pack(pady=10)

# Label Password
label_pass = tk.Label(
    panel,
    text="Password-nya",
    font=("Arial", 14, "italic"),
    bg="#bfbfbf"
)
label_pass.pack(pady=5)

# Entry Password
entry_pass = tk.Entry(
    panel,
    font=("Arial", 12),
    justify="center",
    width=25,
    bg="#9e9e9e",
    show="*"
)
entry_pass.insert(0, "")
entry_pass.pack(pady=10)

# ======================
# FUNGSI TOMBOL
# ======================
def verifikasi():
    nama = entry_nama.get()
    password = entry_pass.get()

    # contoh login sederhana
    if nama == "admin" and password == "1234":
        messagebox.showinfo("Akses", "Login Berhasil ✅")
    else:
        messagebox.showerror("Akses", "Nama / Password salah ❌")

# Label Sudah
label_ok = tk.Label(
    panel,
    text="Sudah?",
    font=("Arial", 14),
    bg="#bfbfbf"
)
label_ok.pack(pady=10)

# Tombol OK
btn_ok = tk.Button(
    panel,
    text="Klik Ok",
    font=("Arial", 12),
    bg="#e0e0e0",
    width=15,
    command=verifikasi
)
btn_ok.pack(pady=10)

# ======================
#ENTER BISA DITEKAN UNTUK LOGIN
entry_pass.bind ('<Return>', lambda event: btn_ok.invoke())
root.bind ('<Return>', lambda event: btn_ok.invoke())
root.mainloop()
