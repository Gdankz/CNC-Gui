import serial
import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import math

button = serial.Serial('COM9', 115200, timeout=1)
button.flushInput()  
root = tk.Tk()
root.title("Sistem Pengawasan dan Keamanan Mesin CNC 3 Axis")
root.geometry("1000x600")
root.configure(bg="#c9c9c9")


# =========================
# LOAD IMAGE LAMPU
# =========================
def load_img(path):
    return ImageTk.PhotoImage(
        Image.open(path).resize((100,100))
    )

start_on = load_img("START_ON.png")
start_off = load_img("START_OFF.png")

stop_on = load_img("STOP_ON.png")
stop_off = load_img("STOP_OFF.png")

emg_on = load_img("EMG_ON.png")
emg_off = load_img("EMG_OFF.png")

# =========================
# HEADER
# =========================
tk.Label(root,
         text="PANEL PENGAWASAN DAN KEAMANAN",
         font=("Arial",18,"bold"),
         bg="#c9c9c9").pack(pady=10)
tk.Frame(root, height=2, bg="black").pack(fill="x")
tk.Frame(root, height=2, bg="grey").pack(fill="x")
main = tk.Frame(root,bg="#c9c9c9")
main.pack(fill="both",expand=True)

# =========================
# PANEL KIRI (LAMPU)
# =========================
left = tk.Frame(main,bg="#9da0a3",width=280)
left.pack(side="left",fill="y")

left.pack_propagate(False)

tk.Label(left,text="INDIKATOR",
         font=("Arial",14,"bold"),
         bg="#9da0a3").pack(pady=10)

def indikator(parent, img, text):
    box = tk.Frame(parent, bg="#9da0a3")
    box.pack(pady=15, padx=20)
    lamp = tk.Label(box, image=img, bg="#9da0a3")
    lamp.pack()
    label = tk.Label(box, text=text,font=("Arial", 12), bg="#9da0a3")
    label.pack(pady=5)
    return lamp

start_lbl = indikator(left,start_off,'START')

stop_lbl = indikator(left,stop_off,'STOP')

emg_lbl = indikator(left,emg_off,'EMERGENCY')

# =========================
# PANEL KANAN
# =========================
right = tk.Frame(main,bg="#c9c9c9")
right.pack(side="left",fill="both",expand=True,padx=20)

# PROGRESS
tk.Label(right,text="PROGRESS BAR",
         font=("Arial",14,"italic"),
         bg="#c9c9c9").pack()

progress = ttk.Progressbar(right,length=500)
progress.pack(pady=10)

progress_text = tk.Label(right,text="0%",bg="#c9c9c9")
progress_text.pack()

# STATUS MESIN
status_mesin = tk.Label(
    right,
    text="STATUS MESIN : Off Condition",
    font=("Arial",18),
    bg="#bfbfbf"
)
status_mesin.pack(pady=20)

# BUTTON PANEL
btn1 = tk.Button(right,text="Jendela Jalur PCB",width=25)
btn1.pack(pady=5)

btn2 = tk.Button(right,text="Simpan Data .xs",width=25)
btn2.pack(pady=5)


# ================= 3 SPINDLE =================
tk.Label(right,
         text="STATUS KECEPATAN SPINDLE",
         font=("Arial",20,"bold"),
         bg="#c9c9c9").pack()

spindle_frame = tk.Frame(right,bg="#c9c9c9")
spindle_frame.pack(pady=20)

fans = []

# ---------- CREATE FAN ----------
def create_fan(parent, text_label):

    frame = tk.Frame(parent,bg="#c9c9c9")
    frame.pack(side="left", padx=40)

    canvas = tk.Canvas(frame,
                       width=140,
                       height=140,
                       bg="#c9c9c9",
                       highlightthickness=0)
    canvas.pack()

    tk.Label(frame,
             text=text_label,
             bg="yellow",
             font=("Arial",12,"bold")).pack(pady=5)

    # simpan data kipas
    fan_data = {
        "canvas": canvas,
        "angle": 0,
        "speed": 0
    }

    fans.append(fan_data)


# buat 3 kipas
create_fan(spindle_frame,"RENDAH")
create_fan(spindle_frame,"SEDANG")
create_fan(spindle_frame,"TINGGI")


# ---------- DRAW FAN ----------
def draw_fans():

    for fan in fans:

        c = fan["canvas"]
        c.delete("all")

        center = 70
        radius = 50

        for i in range(3):
            theta = math.radians(fan["angle"] + i*120)

            x = center + radius*math.cos(theta)
            y = center + radius*math.sin(theta)

            c.create_line(center,center,x,y,
                          width=12,
                          capstyle="round")


# ---------- ROTATION LOOP ----------
def rotate_fans():

    for fan in fans:
        fan["angle"] += fan["speed"]

    draw_fans()
    root.after(40, rotate_fans)

rotate_fans()

#==================
#spindle kontrol
#==================
def set_spindle(mode):
    for fan in fans:
        fan["speed"] = 0
    if mode == 1:
        fans[0]["speed"] = 2
        status_mesin.config(text="STATUS MESIN : RENDAH")
    elif mode == 2:
        fans [1]["speed"] = 6
        status_mesin.config(text="STATUS MESIN : SEDANG")
    elif mode == 3:
        fans[2]["speed"] = 12
        status_mesin.config(text="STATUS MESIN : TINGGI")
    else:
        status_mesin.config(text="STATUS MESIN : OFF")
# =========================
# SIMULASI DATA
# =========================
mode = 0    
def read_serial():
    global mode, fan_speed
    mode = (mode + 1) % 3
    try:
        while button.in_waiting:
            data = button.readline().decode().strip()

        if data:
            print("DATA:", data)

            parts = data.split(',')

            b1 = int(parts[0].split(':')[1])
            b2 = int(parts[1].split(':')[1])

            if b1 == 0:
                start_lbl.config(image=start_on)
                stop_lbl.config(image=stop_off)
                if mode == 0:
                    set_spindle(mode+1)
                elif mode == 1:
                    set_spindle(mode+1)
                else:
                    set_spindle(mode+1)
                # progress jalan
                val = progress['value'] + 10
                if val > 100:
                    val = 0
                    progress['value'] = val
                    progress_text.config(text=f"{int(val)}%")
            if b2 == 0:
                stop_lbl.config(image=stop_on)
                start_lbl.config(image=start_off)

    except Exception as e:
        print("ERROR:", e)

    root.after(50, read_serial)
rotate_fans()
#simulasi()
read_serial()
root.mainloop()
