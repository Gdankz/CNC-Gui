#define LED_PIN 13
#define button1 7
#define button2  8
int buttonstate = 0;
int buttonstate2 = 0;

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  pinMode(button1, INPUT_PULLUP);
  pinMode(button2, INPUT_PULLUP);
}
void loop() {
  buttonstate = digitalRead(button1);
  buttonstate2 = digitalRead(button2);
  Serial.print("b1:");
  Serial.print(buttonstate);
  Serial.print(",b2:");
  Serial.println(buttonstate2);

  if (buttonstate == LOW) {
    digitalWrite(LED_PIN, HIGH);
  }
  if (buttonstate2 == LOW){
    digitalWrite(LED_PIN, LOW);
  }
  delay(50);
}