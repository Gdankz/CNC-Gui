import serial
import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import math

# =========================
# SERIAL
# =========================
button = serial.Serial('COM9', 115200, timeout=1)
button.flushInput()

# =========================
# STATE SYSTEM
# =========================
mode = 1            # 1=RENDAH, 2=SEDANG, 3=TINGGI
running = False     # status mesin
process_done = False
last_b1 = 1
last_b2 = 1

# =========================
# GUI SETUP
# =========================
root = tk.Tk()
root.title("Sistem Pengawasan dan Keamanan Mesin CNC 3 Axis")
root.geometry("1000x600")
root.configure(bg="#c9c9c9")

# =========================
# LOAD IMAGE
# =========================
def load_img(path):
    return ImageTk.PhotoImage(
        Image.open(path).resize((100,100))
    )

start_on = load_img("START_ON.png")
start_off = load_img("START_OFF.png")

stop_on = load_img("STOP_ON.png")
stop_off = load_img("STOP_OFF.png")

emg_on = load_img("EMG_ON.png")
emg_off = load_img("EMG_OFF.png")

# =========================
# HEADER
# =========================
tk.Label(root,text="PANEL PENGAWASAN DAN KEAMANAN",
         font=("Arial",18,"bold"),bg="#c9c9c9").pack(pady=10)

tk.Frame(root, height=2, bg="black").pack(fill="x")
tk.Frame(root, height=2, bg="grey").pack(fill="x")

main = tk.Frame(root,bg="#c9c9c9")
main.pack(fill="both",expand=True)

# =========================
# PANEL KIRI
# =========================
left = tk.Frame(main,bg="#9da0a3",width=280)
left.pack(side="left",fill="y")
left.pack_propagate(False)

tk.Label(left,text="INDIKATOR",
         font=("Arial",14,"bold"),
         bg="#9da0a3").pack(pady=10)

def indikator(parent, img, text):
    box = tk.Frame(parent, bg="#9da0a3")
    box.pack(pady=15, padx=20)
    lamp = tk.Label(box, image=img, bg="#9da0a3")
    lamp.pack()
    tk.Label(box, text=text,font=("Arial", 12), bg="#9da0a3").pack(pady=5)
    return lamp

start_lbl = indikator(left,start_off,'MULAI "START"')
stop_lbl = indikator(left,stop_off,'BERHENTI "STOP"')
emg_lbl = indikator(left,emg_off,'EMERGENCY')

# =========================
# PANEL KANAN
# =========================
right = tk.Frame(main,bg="#c9c9c9")
right.pack(side="left",fill="both",expand=True,padx=20)

tk.Label(right,text="PROGRESS BAR",
         font=("Arial",14,"italic"),
         bg="#c9c9c9").pack()

progress = ttk.Progressbar(right,length=500)
progress.pack(pady=10)

progress_text = tk.Label(right,text="0%",bg="#c9c9c9")
progress_text.pack()

status_mesin = tk.Label(right,
    text="STATUS MESIN : OFF",
    font=("Arial",18),
    bg="#bfbfbf"
)
status_mesin.pack(pady=20)

# =========================
# SPINDLE (ANIMASI)
# =========================
tk.Label(right,
         text="STATUS KECEPATAN SPINDLE",
         font=("Arial",20,"bold"),
         bg="#c9c9c9").pack()

spindle_frame = tk.Frame(right,bg="#c9c9c9")
spindle_frame.pack(pady=20)

fans = []

def create_fan(parent, text_label):
    frame = tk.Frame(parent,bg="#c9c9c9")
    frame.pack(side="left", padx=40)

    canvas = tk.Canvas(frame,width=140,height=140,
                       bg="#c9c9c9",highlightthickness=0)
    canvas.pack()

    tk.Label(frame,text=text_label,
             bg="yellow",font=("Arial",12,"bold")).pack(pady=5)

    fans.append({"canvas":canvas,"angle":0,"speed":0})

create_fan(spindle_frame,"RENDAH")
create_fan(spindle_frame,"SEDANG")
create_fan(spindle_frame,"TINGGI")

def draw_fans():
    for fan in fans:
        c = fan["canvas"]
        c.delete("all")

        center = 70
        radius = 50

        for i in range(3):
            theta = math.radians(fan["angle"] + i*120)
            x = center + radius*math.cos(theta)
            y = center + radius*math.sin(theta)
            c.create_line(center,center,x,y,width=12,capstyle="round")

def rotate_fans():
    for fan in fans:
        fan["angle"] += fan["speed"]
    draw_fans()
    root.after(40, rotate_fans)

# =========================
# KONTROL SPINDLE
# =========================
def set_spindle(mode):
    for fan in fans:
        fan["speed"] = 0

    if mode == 1:
        fans[0]["speed"] = 2
        status_mesin.config(text="STATUS MESIN : RENDAH")
    elif mode == 2:
        fans[1]["speed"] = 6
        status_mesin.config(text="STATUS MESIN : SEDANG")
    elif mode == 3:
        fans[2]["speed"] = 12
        status_mesin.config(text="STATUS MESIN : TINGGI")
    else:
        status_mesin.config(text="STATUS MESIN : OFF")

# =========================
# SERIAL READ (TOGGLE LOGIC)
# =========================
def read_serial():
    global last_b1, last_b2, running, process_done

    try:
        while button.in_waiting:
            data = button.readline().decode().strip()

        if data:
            print("DATA:", data)

            parts = data.split(',')

            b1 = int(parts[0].split(':')[1])
            b2 = int(parts[1].split(':')[1])

            # EDGE DETECTION
            if b1 == 0 and last_b1 == 1:
                running = True

            if b2 == 0 and last_b2 == 1:
                running = False

            last_b1 = b1
            last_b2 = b2

            # UPDATE GUI + SPINDLE
            if running:
                if not process_done:
                    start_lbl.config(image=start_on)
                    stop_lbl.config(image=stop_off)

                    set_spindle(mode)
                    status_mesin.config(text="STATUS MESIN : ON PROGRESS")

                    val = progress['value'] + 5
                    if val > 100:
                        val = 100
                        process_done = True
                        
                    progress['value'] = val
                    progress_text.config(text=f"{int(val)}%")

                else:
                    set_spindle(0)
                    status_mesin.config(text="STATUS MESIN : DONE")

            else:
                start_lbl.config(image=start_off)
                stop_lbl.config(image=stop_on)

                set_spindle(0)
                status_mesin.config(text="STATUS MESIN : OFF")

                progress['value'] = 0
                progress_text.config(text="0%")
                process_done = False
    except Exception as e:
        print("ERROR:", e)

    root.after(50, read_serial)

# =========================
# RUN
# =========================
rotate_fans()
read_serial()
root.mainloop()
